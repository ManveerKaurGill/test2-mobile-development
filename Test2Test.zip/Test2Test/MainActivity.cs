﻿using Android.App;
using Android.OS;
using Android.Support.V7.App;
using Android.Runtime;
using Android.Widget;
using Android.Content;

namespace Test2Test
{
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme", MainLauncher = true)]
    public class MainActivity : AppCompatActivity
    {
        //variable declaration
        SearchView studentsSearch;
        ListView myList;
        Button addNew;
        ArrayAdapter adapter;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.activity_main);
            studentsSearch = FindViewById<SearchView>(Resource.Id.man1);
            myList = FindViewById<ListView>(Resource.Id.man2);
            addNew = FindViewById<Button>(Resource.Id.button);

            studentsSearch.QueryTextChange += (s, e) =>
            {

                // adapter acts as an connect that connects UI component and data source that helps us to fill data in UI component.
                adapter = new ArrayAdapter(this, Android.Resource.Layout.SimpleListItem1, Student.Students);
                myList.Adapter = adapter;
                adapter.Filter.InvokeFilter(e.NewText);
            };

            myList.ItemClick += (s, e) =>
            {
                string name_selected = adapter.GetItem(e.Position).ToString();

                name_selected = name_selected.Substring(name_selected.IndexOf("\n") + 5);
                name_selected = name_selected.Substring(0, name_selected.IndexOf("\n"));
                int position = Student.Ids.IndexOf(name_selected);


                // used to navigate one activity to another
                Intent intent = new Intent(this, typeof(GPA));
                intent.PutExtra("Position", position);
                StartActivity(intent);
            };

            //intent is used to connect to the pages
            addNew.Click += delegate
            {
                Intent intent = new Intent(this, typeof(Register));
                StartActivity(intent);
            };

        }

        // this helps to restart so that we can add new and new students
        protected override void OnRestart()
        {
            base.OnRestart();
            studentsSearch.SetQuery("", false);
            adapter = new ArrayAdapter(this, Android.Resource.Layout.SimpleListItem1, Student.Students);
            myList.Adapter = adapter;
        }


    }
}